#ifndef BASIC_TYPES_H
#define    BASIC_TYPES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
	ERROR = 0, OK = 1
} Status;

typedef enum {
	FALSE = 0, TRUE = 1
} Bool;

#endif