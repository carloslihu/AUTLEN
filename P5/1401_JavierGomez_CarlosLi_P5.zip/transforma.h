#ifndef TRANFORMA_H
#define TRANSFORMA_H
#include "generic_string.h"
#include "afnd.h"
#include "list.h"
#include "cint.h"

AFND * AFNDTransforma(AFND * afnd);
#endif